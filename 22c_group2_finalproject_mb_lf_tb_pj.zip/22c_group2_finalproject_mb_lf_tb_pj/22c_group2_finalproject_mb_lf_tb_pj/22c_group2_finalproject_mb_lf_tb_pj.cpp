#include "CentralApplication.h"

using namespace std;
int main()
{
	CentralApplication logger;
	logger.menu();
	return 0;
}
