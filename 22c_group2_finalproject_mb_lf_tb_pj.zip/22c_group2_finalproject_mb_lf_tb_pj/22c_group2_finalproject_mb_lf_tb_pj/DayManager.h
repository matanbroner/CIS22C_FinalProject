/*
Day Manager Class
=================
This class is responsible for the reading into and writing out to
an input file of logged days by the user. It follows a specified identical
format for the read in and write out to ensure reusablility.
The class also creates new days and allows users to search for foods to add to a new day
or to modify the current one they are logging after a pause.
*/


#ifndef DAYMANAGER_H
#define DAYMANAGER_H

#include <string>
#include <iostream>
#include <fstream>
#include "List.h"
#include "BinarySearchTree.h"
#include "HashTable.h"
#include "Food.h"
#include "Stack.h"
#include "Day.h"

class DayManager {
private:
	static bool choice(); // gets yes or no answer from user
	Day* currentDay = nullptr; // the pointer to the value of the last day logged with foods
	static int mostRecentDate; // integer to keep track of last date logged
	List<Food> currentDayFood; // list of foods to store foods for continued logging of a day
							   /*
							   This methods takes a set of three macronutrient holding doubles, and a hash table
							   which is filled with foods. It then continually prompts the user to search for foods to add to the current day's
							   log, and at the end, it will log the total macronutrients from all the foods that were logged.
							   Pre: double protein, carb, fat, Hash Table of foods for search
							   Post: protein, fat, and carb are the culmination ofall logged foods' macronutrients
							   */
	void readFoodsFromUser(double&, double&, double&, HashTable<Food>&);
public:
	//static Stack removedDays;
	DayManager(); // constructor
	~DayManager();
	/*
	This method takes a hash table of available foods, a hash table of ordered days, and a binary
	search tree of days sorted by total calories eaten. It creates a new day object and uses the
	readFoodsFromUser method to log foods for this new day. It then adds the day to the hash table of days and to
	the binary search tree of days.
	Pre: Hash Table of foods, Hash Table of days, BST of days
	Post: days Hash Table and BST now contain one more entry
	Return: true is all succesful
	*/
	bool createNewDay(HashTable<Food>&, HashTable<Day>&, BinarySearchTree<Day>&);

	/*
	This method takes an open input file stream, a BST of days, and a hash table of days.
	It parses the input file and adds Day values to the hash table and BST in their correct sorted fashion.
	Should only be used in the scope of this project, as it is extremly format specified.
	Pre: ifstream, HashTable, BST
	Post: HashTable and BST include n number of Days (where n is the number of lines in the file)
	Return: true if read
	*/
	static bool readFromDayFile(std::ifstream &input, BinarySearchTree<Day> &tree, HashTable<Day> &dayTable);

	/*
	This method takes an open output file stream and a hash table of type Day.
	It parses the hash table indexes and writes all days to the output file in the same
	format presented in the read in function for reusability.
	Should only be used in the scope of this project, as it is extremly format specified.
	Pre: ofstream, HashTable
	Post: output file includes n number of lines (where n is the number of days in the hash table)
	Return: true if written
	*/
	static bool writeToDataFile(std::ofstream& output, HashTable<Day> &dayTable);

	/*
	This method is meant to pretend as though it is editing the most recent date logged,
	in order to allow a user to continue to add foods to the logged day they last created.
	It finds the last day in the given days Hash Table and BST, deletes it, and then uses
	the list of foods in the class to continue asking foods from the user. It then adds the day back into
	the structures with it's modified macornutrient count.
	Pre: Hash Table of available foods, Hash Table of days, BST of days
	Post: days Hash Table and BST now have the same number of entries, with the one with the
	largest date modified.
	Return: true if succesful
	*/
	bool editCurrentDay(HashTable<Food>&, HashTable<Day>&, BinarySearchTree<Day>&);
};

int DayManager::mostRecentDate = 0;

DayManager::DayManager() {}
DayManager::~DayManager() {}

bool DayManager::choice() { // gets yes or no answer from user and return a boolean accordingly

	bool valid = false;
	std::string answer;

	do {
		std::cout << "[Y/N]\n--> ";
		getline(std::cin, answer);
		std::transform(answer.begin(), answer.end(), answer.begin(), ::tolower);

		valid =
			(answer == "y") ||
			(answer == "n") ||
			(answer == "yes") ||
			(answer == "no");
	} while (!valid);
	return ((answer == "y") || (answer == "yes")) ? true : false;
}

bool DayManager::createNewDay(HashTable<Food>& foodsPresent, HashTable<Day>& dayTable, BinarySearchTree<Day>& dayTree)
{
	this->currentDayFood.emptyListContents(); // food list is reset to indicate a new day
	double protein = 0, carb = 0, fat = 0;
	++mostRecentDate; // increment date
	this->readFoodsFromUser(protein, fat, carb, foodsPresent); // log all foods eaten
	Day temp(fat, carb, protein, mostRecentDate); // create a day with all macronutrients logged
	this->currentDay = &temp; // save this day to the currentDay pointer for future edits
	dayTable.insert(temp, std::to_string(mostRecentDate)); // insert into HT
	dayTree.insert(temp); // insert into BST
	return true;
}

bool DayManager::editCurrentDay(HashTable<Food> &foods, HashTable<Day> &dayTable, BinarySearchTree<Day> &dayTree)
{
	if (this->currentDay != nullptr) // if a day has been logged since the start of the program
	{
		double protein = 0, carb = 0, fat = 0;
		Day::sortByDates(); // days are now sorted by their date value rather than calories
		dayTable.remove(std::to_string(mostRecentDate)); // find the day with most recent date in HT and remove
		dayTree.remove(*currentDay);  // remove the same day from the BST
		this->readFoodsFromUser(protein, fat, carb, foods); // log foods from user using same list from earlier read
		Day temp(fat, carb, protein, mostRecentDate); // create new day with updated macros
		Day::sortByCalories(); // sort by calories now for BST insert
		dayTree.insert(temp); // add into the BST
		dayTable.insert(temp, std::to_string(mostRecentDate)); // add back into the hash table with same date
		this->currentDay = &temp; // point to new (same) day
		return true;
	}
	else return false;
}



bool DayManager::readFromDayFile(std::ifstream &input, BinarySearchTree<Day> &tree, HashTable<Day> &dayTable)
{
	Day::sortByCalories();
	// validate file
	if (!input.is_open()) {
		return false;
	}
	std::string tempString;
	getline(input, tempString); // trash header line
	getline(input, tempString); // get calorie target
	Day::setCT(std::stoi(tempString)); // set calorie target
	std::string date, carb, fat, protein;
	while (getline(input, protein, ' ')) {
		getline(input, carb, ' ');
		getline(input, fat, ' ');
		getline(input, date);
		Day temp(std::stod(fat), std::stod(carb), std::stod(protein), std::stoi(date));
		tree.insert(temp);
		dayTable.insert(temp, date);
		if (temp.getDate() > mostRecentDate)
			mostRecentDate = temp.getDate();
	}
	return true;
}

void DayManager::readFoodsFromUser(double &protein, double &fat, double &carb, HashTable<Food> &foodsPresent)
{
	std::string searchTerm = "pie";
	while (searchTerm != "")
	{
		std::cout << "Food eaten to add [Press ENTER to stop adding foods]: ";
		getline(std::cin, searchTerm);
		if (searchTerm == "") // if user presses ENTER without food search term
			break;
		StringAssistant::nameFormatter(searchTerm);
		StringAssistant::trimSpaces(searchTerm);
		int index = foodsPresent.searchFood(searchTerm);
		if (index == -1) // if food not found
		{
			std::cout << "Would you like to add '" << searchTerm << "' to your available foods?" << std::endl;
			if (choice()) // if user wishes to add food to table
			{
				Food newFood = FoodCreator::create(searchTerm);
				foodsPresent.insertFood(newFood, searchTerm);
				int indexOfNewFood = foodsPresent.searchFood(searchTerm);
				this->currentDayFood.add(foodsPresent[indexOfNewFood]->getData());
				std::cin.ignore();
				std::cout << "'" << searchTerm << "' has been added to your available foods, and to today's food log!" << std::endl;
			}
			else std::cout << "Okay, not adding '" << searchTerm << "' to database." << std::endl;
		}
		else this->currentDayFood.add(foodsPresent[index]->getData());
	}
	std::cout << "Okay, so today you have eaten:\n["; // read back logged foods
	this->currentDayFood.printList();
	std::cout << "]" << std::endl;
	for (int i = 0; i < this->currentDayFood.getCount(); i++) // calculate macros
	{
		protein += this->currentDayFood.getDataAtIndex(i).getProtein();
		fat += this->currentDayFood.getDataAtIndex(i).getFat();
		carb += this->currentDayFood.getDataAtIndex(i).getCarb();
	}
}

bool DayManager::writeToDataFile(std::ofstream &output, HashTable<Day> &dayTable)
{
	Day::sortByDates();
	List<Day> dayList;
	output << "p c f d" << std::endl;
	output << Day::getTargetCal() << std::endl;
	for (int i = 0; i < dayTable.getSize(); i++)
	{
		if (dayTable[i])
		{
			dayList.add(dayTable[i]->getData());
			dayList.sortListAcsending();
		}
	}
	while (dayList.getCount() > 0)
	{
		Day temp = dayList.deleteHead();
		output << temp.getDayProtein() << " " << temp.getDayCarb() << " " << temp.getDayFat() << " " << temp.getDate();
		if (dayList.getCount() > 0)
			output << std::endl;
	}
	return true;
}



#endif
