//
//  GraphManager.h
//  CIS22C_FinalProject
//
//  Created by Matan Broner on 12/5/18.
//  Copyright � 2018 Matan Broner. All rights reserved.
//

#ifndef GraphManager_h
#define GraphManager_h

#include <conio.h>
#include <stdio.h>
#include "Graph.h"
#include "Day.h"
#include "HashTable.h"

#define KEY_LEFT 75
#define KEY_RIGHT 77
#define QUIT_KEY 113

class GraphManager
{
private:
	int leftOverDays = 0;
	int numberOfWeeks = 0;
	int currentWeek = 1;
    bool averages = false;
	void getNumberOfWeeks(HashTable<Day>&);
	void fillArrayBasedOnMacronutrient(HashTable<Day>&, int[], int, int, int);
	static int chooseMacroToDisplay();
    void weeklyOrAverages();
	static int getInteger(int, int);
	void getArrowResponse();
	static std::string nameOfMacro(int);
public:
	void graphMenu(HashTable<Day>&);
};

// Public Functions

void GraphManager::graphMenu(HashTable<Day> &dayTable)
{
	if (system("cls")) system("clear");
	this->currentWeek = 1;
	this->getNumberOfWeeks(dayTable);
	int tableSize = dayTable.getCount();
	this->weeklyOrAverages();
	if (system("cls")) system("clear");
	int macroChoice = chooseMacroToDisplay();
	if (system("cls")) system("clear");
	std::cin.ignore();
	while (!this->averages && this->currentWeek <= this->numberOfWeeks)
	{
		int dayMacroArray[7];  // max number of days displayed at once is 7
		if (numberOfWeeks)
		{
			if (currentWeek <= numberOfWeeks && !leftOverDays)
			{
				int startAt = 1 + ((currentWeek - 1) * 7);
				this->fillArrayBasedOnMacronutrient(dayTable, dayMacroArray, startAt, 7, macroChoice);
				graph::graph(dayMacroArray, 7);
			}
			else if (currentWeek <= numberOfWeeks && leftOverDays)
			{
				if (currentWeek != numberOfWeeks)
				{
					int startAt = 1 + ((currentWeek - 1) * 7);
					this->fillArrayBasedOnMacronutrient(dayTable, dayMacroArray, startAt, 7, macroChoice);
					graph::graph(dayMacroArray, 7);
				}

				else
				{
					int startAt = 1 + ((currentWeek - 1) * 7);
					this->fillArrayBasedOnMacronutrient(dayTable, dayMacroArray, startAt, leftOverDays, macroChoice);
					graph::graph(dayMacroArray, leftOverDays);
				}

			}
		}

		else
		{
			int startAt = 1;
			this->fillArrayBasedOnMacronutrient(dayTable, dayMacroArray, startAt, leftOverDays, macroChoice);
			graph::graph(dayMacroArray, leftOverDays);
		}
		std::cout << "[DISPLAYING " << nameOfMacro(macroChoice) << " COUNT FOR WEEK " << this->currentWeek << " of " << numberOfWeeks << std::endl;
		std::cout << "TAB BETWEEN PAGES USING ARROW KEYS [<--] AND [-->] PRESS 'q' TO QUIT GRAPHER" << std::endl;
		getArrowResponse();
		if (system("cls")) system("clear");
	} // While Bracket

	if (this->averages)
	{
		if (numberOfWeeks)
		{
			if (leftOverDays)
				numberOfWeeks--;
			int sum = 0;
			int tempHolder[7];
			int* averagesArray = new int[numberOfWeeks];
			for (int i = 0; i < numberOfWeeks; i++)
			{
				int startAt = 1 + (i * 7);
				fillArrayBasedOnMacronutrient(dayTable, tempHolder, startAt, 7, macroChoice);
				for (int i = 0; i < 7; i++)
					sum += tempHolder[i];
				averagesArray[i] = (sum / 7);
			}
			graph::graph(averagesArray, numberOfWeeks);
			delete averagesArray;
		}
		else std::cout << "Grapher only averages entire seven day weeks, please log more days." << std::endl;
	}

} // Function Bracket


  // Private Functions

void GraphManager::getNumberOfWeeks(HashTable<Day> &dayTable)
{
	if (dayTable.getCount() % 7 == 0)
		this->numberOfWeeks = dayTable.getCount() / 7;
	else
	{
		this->numberOfWeeks = (dayTable.getCount() / 7) + 1;
		this->leftOverDays = dayTable.getCount() % 7;
	}
}

void GraphManager::fillArrayBasedOnMacronutrient(HashTable<Day> &dayTable, int dayArray[], int startIndex, int fillSize, int option)
{
	switch (option)
	{
	case 1:
	{
		for (int i = 0; i < fillSize; i++)
		{
			dayArray[i] = dayTable[dayTable.search(std::to_string(startIndex++))]->getData().totalCal();
		}
		break;
	}
	case 2:
	{
		for (int i = 0; i < fillSize; i++)
		{
			dayArray[i] = dayTable[dayTable.search(std::to_string(startIndex++))]->getData().getDayProtein();
		}
		break;
	}
	case 3:
	{
		for (int i = 0; i < fillSize; i++)
		{
			dayArray[i] = dayTable[dayTable.search(std::to_string(startIndex++))]->getData().getDayCarb();
		}
		break;
	}
	case 4:
	{
		for (int i = 0; i < fillSize; i++)
		{
			dayArray[i] = dayTable[dayTable.search(std::to_string(startIndex++))]->getData().getDayFat();
		}
		break;
	}
	default: std::cout << "*** misuse of the array filling function trigerred ***" << std::endl;
	}
}

int GraphManager::chooseMacroToDisplay()
{
	std::cout << "=== Grapher Menu ===" << std::endl;
	std::cout << "[1] -- Display by Calorie count" << std::endl;
	std::cout << "[2] -- Display by Protein count" << std::endl;
	std::cout << "[3] -- Display by Carb count" << std::endl;
	std::cout << "[4] -- Display by Fat count" << std::endl;
	return getInteger(1, 4);
}

int GraphManager::getInteger(int minAcceptable, int maxAcceptable)
{
	int response = -100;
	while (response < minAcceptable || response > maxAcceptable)
	{
		std::cout << "--> ";
		std::cin >> response;
		if (std::cin.fail())
			StringAssistant::clearInput();
	}
	return response;
}

void GraphManager::getArrowResponse()
{
	bool validInput = false;
	unsigned int character;
	while (!validInput)
	{
		character = _getch();
		switch (character)
		{
		case KEY_RIGHT:
			{
			if (this->currentWeek < this->numberOfWeeks)
				{
				this->currentWeek++;
				validInput = true;
				}
			break;
			}
		case KEY_LEFT:
			{
			if (this->currentWeek > 1)
				{
				this->currentWeek--;
				validInput = true;
				}
			break;
			}
		case QUIT_KEY:
			{
			std::cout << "Leaving Grapher..." << std::endl;
			this->currentWeek = (this->numberOfWeeks + 100); // fake value
			validInput = true;
			}
			break;
		}
	}
}

std::string GraphManager::nameOfMacro(int choice)
{
	switch (choice)
	{
	case 1: return "CALORIE"; break;
	case 2: return "PROTEIN"; break;
	case 3: return "CARB"; break;
	case 4: return "FAT"; break;
	default: return "[not a valid macro]";
	}
}

void GraphManager::weeklyOrAverages()
{
	std::cout << "=== Grapher Menu ===" << std::endl;
	std::cout << "[1] -- Display Weekly Stats (individual days)" << std::endl;
	std::cout << "[2] -- Display Average Stats" << std::endl;
	int response = getInteger(1, 2);
	if (response == 1)
		this->averages = false;
	else if (response == 2) this->averages = true;
	std::cin.ignore();
}

#endif /* GraphManager_h */