/*
Structure Printer Class
=======================
This class is responsible for printing structures,
currently limited to onl Binary Search Trees.
*/

#ifndef StructurePrinter_h
#define StructurePrinter_h



#include "BinarySearchTree.h"
#include "List.h"


template <typename T>
class StructurePrinter
{
private:
	/*
	BST Printing Related
	*/

	/*
	This method takes a node in a BST, and recursivley traverses the tree and printing
	the following nodes' values along with a set of symbols to represent tree branches,
	which depends on if the node is a right or left child of its parent.
	Pre: string fixed (set of symbols to print with value), node in BST, boolean indicating left child node
	Post: Tree prints to console
	Return: none
	*/
	static void _printBST(std::string, BSTNode<T>*, bool);
public:
	static void printBinarySearchTree(BinarySearchTree<T>&); // public function
};

/*
BST Printing Related
*/
template <typename T>
void StructurePrinter<T>::_printBST(std::string fixed, BSTNode<T> *node, bool isLeftNode)
{
	if (node != nullptr) // if node exists in tree
	{
		std::cout << fixed; // fixed is a set of spacing and branches

		if (isLeftNode)
			std::cout << "L:|---";
		else std::cout << "R:~___";

		// print the value of the node
		std::cout << node->getData() << std::endl;

		// enter the next tree level - left and right branch
		_printBST(fixed + (isLeftNode ? "|   " : "    "), node->getLeft(), true);
		_printBST(fixed + (isLeftNode ? "|   " : "    "), node->getRight(), false);
	}
}

template <typename T>
void StructurePrinter<T>::printBinarySearchTree(BinarySearchTree<T> &tree)
{
	_printBST("", tree.retrieveRootPointer(), false);
}


#endif /* StructurePrinter_h */
