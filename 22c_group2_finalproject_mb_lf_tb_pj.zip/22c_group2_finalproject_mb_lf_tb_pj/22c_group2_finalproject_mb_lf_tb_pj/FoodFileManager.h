/*
Food File Manager Class
=======================
This class is meant to perform all necessary reading into and writing out to a file of foods
for this given project. It has the ability to read into a hash table of foods and then write
back out to the original file with all the same foods plus the ones added during the session
*/


// add food by quantity
#ifndef FoodFileManager_h
#define FoodFileManager_h
#include "HashTable.h"
#include <fstream>
#include <string>
class FoodFileManager
{
private:
	/*
	This method is meant to parse a string which contains the unit and quantity of a given food.
	It is directly related to the specified format of this project's input file for foods and
	should not be used outside of this project's scope unless modified
	Pre: string total phrase, string quantity, string unit
	Post: quantity and unit have been modified accordingly
	Return: none
	(ex. 3 tsp. --> quantity = 3, unit = tsp.)
	*/
	static void parseQuantityAndUnit(std::string&, std::string&, std::string&);
public:
	/*
	This method takes an open input file stream and a hash table of type Food.
	It parses the input file and adds Food values to the hash table.
	Should only be used in the scope of this project, as it is extremly format specified.
	Pre: ifstream, HashTable
	Post: HashTable includes n number of foods (where n is the number of lines in the file)
	Return: true if read
	*/
	static bool readFromInputFileIntoTable(std::ifstream&, HashTable<Food>&);

	/*
	This method takes an open output file stream and a hash table of type Food.
	It parses the hash table indexes and writes all foods to the output file in the same
	format presented in the read in function for reusability.
	Should only be used in the scope of this project, as it is extremly format specified.
	Pre: ofstream, HashTable
	Post: output file includes n number of lines (where n is the number of foods in the hash table)
	Return: true if written
	*/
	static bool writeTableToInputFile(std::ofstream& outFile, HashTable<Food> &table);
};

bool FoodFileManager::readFromInputFileIntoTable(std::ifstream &input, HashTable<Food> &table)
{
	if (!input.is_open())
		return false;
	while (input.is_open() && !input.eof())
	{
		std::string tempString;
		std::string name, quantity, unit, carb, fat, protein;
		getline(input, name, '(');
		getline(input, tempString, ')');
		parseQuantityAndUnit(tempString, quantity, unit);
		getline(input, tempString, '-');
		getline(input, tempString, ' ');
		getline(input, carb, ' ');
		getline(input, fat, ' ');
		getline(input, protein);
		Food addedFood(name, std::stod(protein), std::stod(carb), std::stod(fat), std::stod(quantity), unit);
		table.insertFood(addedFood, name);
	}
	input.close();
	return true;
}

bool FoodFileManager::writeTableToInputFile(std::ofstream& outFile, HashTable<Food> &table)
{
	int actualEntiresCount = 0;
	if (table.getCount() > 0)
		for (int i = 0; i < table.getSize(); i++)
		{
			if (table[i] != nullptr)
			{
				actualEntiresCount++;
				std::string nameOfFood = table[i]->getData().getName();
				StringAssistant::trimSpaces(nameOfFood);
				outFile << nameOfFood << " (";
				outFile << table[i]->getData().getQuantity() << " ";
				outFile << table[i]->getData().getUnit() << ") - ";
				outFile << table[i]->getData().getCarb() << " ";
				outFile << table[i]->getData().getFat() << " ";
				outFile << table[i]->getData().getProtein();
				if (actualEntiresCount < table.getCount())
					outFile << std::endl;
			}
		}
	return true;
}

void FoodFileManager::parseQuantityAndUnit(std::string &container, std::string &quantity, std::string &unit)
{
	bool dec = false;
	for (char c : container)
	{
		if (isdigit(c) || (c == '.' && !dec))
		{
			quantity += c;
			if (c == '.')
				dec = true;
		}
		else if (c != ' ')
			unit += c;
	}
}


#endif /* FoodFileManager_h */
