#include "CentralApplication.h"

using namespace std;
int main()
{
	CentralApplication men;
	men.menu();
	return 0;
}